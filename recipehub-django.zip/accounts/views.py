from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import RegisterForm, UserForm, ProfileForm
from recipes.models import Recipe

def register(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Welcome to RecipeHub!")
            return redirect("recipe_list")
    else:
        form = RegisterForm()
    return render(request, "registration/register.html", {"form": form})

@login_required
def profile(request):
    recipes = Recipe.objects.filter(author=request.user).order_by("-created_at")
    return render(request, "accounts/profile.html", {"recipes": recipes})

@login_required
def edit_profile(request):
    profile = request.user.profile
    if request.method == "POST":
        u_form = UserForm(request.POST, instance=request.user)
        p_form = ProfileForm(request.POST, request.FILES, instance=profile)
        if u_form.is_valid() and p_form.is_valid():
            u_form.save()
            p_form.save()
            messages.success(request, "Profile updated.")
            return redirect("profile")
    else:
        u_form = UserForm(instance=request.user)
        p_form = ProfileForm(instance=profile)
    return render(request, "accounts/edit_profile.html", {"u_form": u_form, "p_form": p_form})
