# RecipeHub

A beginner-friendly Django recipe sharing website.

## Features
- User registration, login, logout
- Add / view / edit / delete recipes (CRUD)
- Categories: Breakfast, Lunch, Dinner, Snacks, Desserts
- Search by title or category
- User profile page with their own recipes
- Bootstrap 5 responsive UI
- Image uploads

## Setup

```bash
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt

python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Then open http://127.0.0.1:8000/

## Project Structure
- `recipehub/` — project settings & root urls
- `accounts/` — registration, login, profile
- `recipes/` — recipe CRUD, categories, search
- `templates/` — HTML templates (Bootstrap 5)
- `static/` — CSS
- `media/` — uploaded recipe images
