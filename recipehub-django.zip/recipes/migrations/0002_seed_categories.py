from django.db import migrations

def seed(apps, schema_editor):
    Category = apps.get_model("recipes", "Category")
    for name in ["Breakfast", "Lunch", "Dinner", "Snacks", "Desserts"]:
        Category.objects.get_or_create(name=name)

def unseed(apps, schema_editor):
    Category = apps.get_model("recipes", "Category")
    Category.objects.filter(name__in=["Breakfast","Lunch","Dinner","Snacks","Desserts"]).delete()

class Migration(migrations.Migration):
    dependencies = [("recipes", "0001_initial")]
    operations = [migrations.RunPython(seed, unseed)]
