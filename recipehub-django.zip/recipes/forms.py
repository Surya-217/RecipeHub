from django import forms
from .models import Recipe

class RecipeForm(forms.ModelForm):
    class Meta:
        model = Recipe
        fields = ["title", "category", "ingredients", "instructions", "cooking_time", "image"]
        widgets = {
            "ingredients": forms.Textarea(attrs={"rows": 5, "placeholder": "One ingredient per line"}),
            "instructions": forms.Textarea(attrs={"rows": 6}),
        }
