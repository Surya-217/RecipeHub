from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from django.http import HttpResponseForbidden
from .models import Recipe, Category
from .forms import RecipeForm

def recipe_list(request):
    q = request.GET.get("q", "").strip()
    category_id = request.GET.get("category", "")
    recipes = Recipe.objects.select_related("category", "author").all()
    if q:
        recipes = recipes.filter(Q(title__icontains=q) | Q(category__name__icontains=q))
    if category_id:
        recipes = recipes.filter(category_id=category_id)
    categories = Category.objects.all()
    return render(request, "recipes/recipe_list.html", {
        "recipes": recipes,
        "categories": categories,
        "q": q,
        "selected_category": category_id,
    })

def recipe_detail(request, pk):
    recipe = get_object_or_404(Recipe, pk=pk)
    return render(request, "recipes/recipe_detail.html", {"recipe": recipe})

@login_required
def recipe_create(request):
    if request.method == "POST":
        form = RecipeForm(request.POST, request.FILES)
        if form.is_valid():
            recipe = form.save(commit=False)
            recipe.author = request.user
            recipe.save()
            messages.success(request, "Recipe added!")
            return redirect(recipe.get_absolute_url())
    else:
        form = RecipeForm()
    return render(request, "recipes/recipe_form.html", {"form": form, "title": "Add Recipe"})

@login_required
def recipe_edit(request, pk):
    recipe = get_object_or_404(Recipe, pk=pk)
    if recipe.author != request.user:
        return HttpResponseForbidden("You cannot edit this recipe.")
    if request.method == "POST":
        form = RecipeForm(request.POST, request.FILES, instance=recipe)
        if form.is_valid():
            form.save()
            messages.success(request, "Recipe updated.")
            return redirect(recipe.get_absolute_url())
    else:
        form = RecipeForm(instance=recipe)
    return render(request, "recipes/recipe_form.html", {"form": form, "title": "Edit Recipe"})

@login_required
def recipe_delete(request, pk):
    recipe = get_object_or_404(Recipe, pk=pk)
    if recipe.author != request.user:
        return HttpResponseForbidden("You cannot delete this recipe.")
    if request.method == "POST":
        recipe.delete()
        messages.success(request, "Recipe deleted.")
        return redirect("recipe_list")
    return render(request, "recipes/recipe_confirm_delete.html", {"recipe": recipe})
